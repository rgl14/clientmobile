import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inplay',
  templateUrl: './inplay.component.html',
  styleUrls: ['./inplay.component.scss']
})
export class InplayComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
