import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marketresult',
  templateUrl: './marketresult.component.html',
  styleUrls: ['./marketresult.component.scss']
})
export class MarketresultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
