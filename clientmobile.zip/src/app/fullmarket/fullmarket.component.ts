import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullmarket',
  templateUrl: './fullmarket.component.html',
  styleUrls: ['./fullmarket.component.scss']
})
export class FullmarketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
